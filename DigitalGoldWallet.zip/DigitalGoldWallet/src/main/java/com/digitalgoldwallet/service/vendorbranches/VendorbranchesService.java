package com.digitalgoldwallet.service.vendorbranches;

import java.util.List;

import com.digitalgoldwallet.exception.DuplicateVendorBranchException;
import com.digitalgoldwallet.exception.InvalidBranchIDException;
import com.digitalgoldwallet.exception.InvalidVendorIDException;
import com.digitalgoldwallet.exception.VendorBranchNotFoundException;
import com.digitalgoldwallet.model.VendorBranches;

public interface VendorbranchesService {
	
	public List<VendorBranches> GetAllVendorBranches();
	public VendorBranches findVendorbranchesByBranchID(int branch_id) throws InvalidBranchIDException, VendorBranchNotFoundException;
	public VendorBranches findVendorbranchesByVendorID(int vendor_id)throws InvalidVendorIDException, VendorBranchNotFoundException;   
	
	
	public void addVendorBranch(VendorBranches v) throws DuplicateVendorBranchException;
	public VendorBranches updateVendorBranches(VendorBranches branchid) throws InvalidBranchIDException;
	 
	public void transfer(int sourceBranchId, int destinationBranchId, double quantity) throws InvalidBranchIDException;
	
	List<VendorBranches> findVendorbranchesByCountry(String country) throws VendorBranchNotFoundException ;
	public List<VendorBranches> findVendorbranchesByState(String state)throws VendorBranchNotFoundException ;
	public List<VendorBranches> findVendorbranchesByCity(String city)throws VendorBranchNotFoundException ;
	
	
	
	
	
	
	
	
	
	
	
	

}
