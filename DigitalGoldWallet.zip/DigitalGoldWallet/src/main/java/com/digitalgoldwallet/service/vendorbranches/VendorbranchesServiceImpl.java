package com.digitalgoldwallet.service.vendorbranches;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalgoldwallet.dao.vendorbranches.VendorbranchesRepository;
import com.digitalgoldwallet.exception.DuplicateVendorBranchException;
import com.digitalgoldwallet.exception.InvalidBranchIDException;
import com.digitalgoldwallet.exception.InvalidUserIDException;
import com.digitalgoldwallet.exception.InvalidVendorIDException;
import com.digitalgoldwallet.exception.UserNotFoundException;
import com.digitalgoldwallet.exception.VendorBranchNotFoundException;
import com.digitalgoldwallet.model.VendorBranches;



@Service
public class VendorbranchesServiceImpl implements VendorbranchesService {
	
	@Autowired
	VendorbranchesRepository VendorbranchesDao;

	@Override
	public List<VendorBranches> GetAllVendorBranches() {
		// TODO Auto-generated method stub
		return VendorbranchesDao.findAll();
	}

	@Override
	public VendorBranches findVendorbranchesByBranchID(int branch_id) throws InvalidBranchIDException, VendorBranchNotFoundException{
		// TODO Auto-generated method stub
	Optional<VendorBranches> vendorbranches=VendorbranchesDao.findById(branch_id);
	if(branch_id <= 0) {
		throw new InvalidBranchIDException("vendorbranch id given is invalid");
	}
	if(!vendorbranches.isPresent()) {
		throw new VendorBranchNotFoundException("vendorbranch with this id is not present");
	}
		
		return vendorbranches.get();
	}

	@Override
	public VendorBranches findVendorbranchesByVendorID(int vendor_id) throws InvalidVendorIDException, VendorBranchNotFoundException {
		// TODO Auto-generated method stub
		Optional<VendorBranches> vendors=VendorbranchesDao.findById(vendor_id);
		if(vendor_id <= 0) {
			throw new InvalidVendorIDException("vendorbranch id given is invalid");
		}
		if(!vendors.isPresent()) {
			throw new VendorBranchNotFoundException("vendorbranch with this id is not present");
		}
			return vendors.get();
	}
	
	
	
	@Transactional
	@Override
	public void addVendorBranch(VendorBranches add) throws DuplicateVendorBranchException{
		
		if(add.getBranchid() <= 0) {
			throw new DuplicateVendorBranchException("Id given is already in use!");
		}
	    VendorbranchesDao.saveAndFlush(add);	
	}

	@Override
	public VendorBranches updateVendorBranches(VendorBranches branchid) throws InvalidBranchIDException {
		// TODO Auto-generated method stub
		if(branchid.getBranchid() <= 0) {
			throw new InvalidBranchIDException("The id given is invalid!");
		}
		Optional<VendorBranches> vendorbranches=VendorbranchesDao.findById(branchid.getBranchid());
		VendorBranches id=vendorbranches.get();
		id.setVendorbranch(branchid.getVendorbranch());
		id.setAddress(branchid.getAddress());
		id.setQuantity(branchid.getQuantity());
		id.setCreatedAt(branchid.getCreatedAt());
		return branchid;
	}
	
	
	

	@Override
	public void transfer(int sourceBranchId, int destinationBranchId, double quantity)  throws InvalidBranchIDException{
		//VendorBranches sourceVendor = VendorbranchesDao.findById(sourceBranchId);
		Optional<VendorBranches> sourceVendor = VendorbranchesDao.findById(sourceBranchId);
		if (!sourceVendor.isPresent()) {
	        throw new InvalidBranchIDException("Source branch ID does not exist: " + sourceBranchId);
	    }
		Optional<VendorBranches> destinationVendor = VendorbranchesDao.findById(destinationBranchId);
		if (!destinationVendor.isPresent()) {
	        throw new InvalidBranchIDException("Destination branch ID does not exist: " + destinationBranchId);
	    }
		sourceVendor.get().setQuantity(sourceVendor.get().getQuantity()-quantity);
		destinationVendor.get().setQuantity(destinationVendor.get().getQuantity()+quantity);
	}
	
	
	
	
	

	@Override
	public List<VendorBranches> findVendorbranchesByCity(String city) throws VendorBranchNotFoundException {
		// TODO Auto-generated method stub
		List<VendorBranches> vendorbranches=VendorbranchesDao.findVendorbranchesByCity(city);
		if(city.isEmpty()) {
			throw new VendorBranchNotFoundException("Vendorbranches with the given city are not present!");
		}
		return vendorbranches;
		
	}

	@Override
	public List<VendorBranches> findVendorbranchesByState(String state) throws VendorBranchNotFoundException {
		// TODO Auto-generated method stub
		List<VendorBranches> vendorbranches=VendorbranchesDao.findVendorbranchesByState(state);
		if(state.isEmpty()) {
			throw new VendorBranchNotFoundException("Vendorbranches with the given city are not present!");
		}
		return vendorbranches;

	}

	@Override
	public List<VendorBranches> findVendorbranchesByCountry(String country) throws VendorBranchNotFoundException {
		// TODO Auto-generated method stub
		List<VendorBranches> vendorbranches=VendorbranchesDao.findVendorbranchesByCountry(country);
		if(country.isEmpty()) {
			throw new VendorBranchNotFoundException("Vendorbranches with the given city are not present!");
		}
		return vendorbranches;
	}
	
}
	
	
	
	

	
	


