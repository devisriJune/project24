package com.digitalgoldwallet.dao.vendorbranches;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.digitalgoldwallet.model.VendorBranches;


@Repository
public interface VendorbranchesRepository extends JpaRepository<VendorBranches,Integer>{
	
	@Query("SELECT u FROM VendorBranches u WHERE u.address1.city=:city ") //JPQL
	public List<VendorBranches> findVendorbranchesByCity(@Param("city") String city);
	
	@Query("SELECT u FROM VendorBranches u WHERE u.address1.state=:state ") //JPQL
	public List<VendorBranches> findVendorbranchesByState(@Param("state") String state);
	
	@Query("SELECT u FROM VendorBranches u WHERE u.address1.country=:country ") //JPQL
	public List<VendorBranches> findVendorbranchesByCountry(@Param("country") String country);
}
