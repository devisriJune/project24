package com.digitalgoldwallet.controller.vendorbranches;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalgoldwallet.exception.VendorBranchNotFoundException;
import com.digitalgoldwallet.controller.successresponse.SuccessResponse;
import com.digitalgoldwallet.exception.DuplicateVendorBranchException;
import com.digitalgoldwallet.exception.InvalidBranchIDException;
import com.digitalgoldwallet.exception.InvalidUserIDException;
import com.digitalgoldwallet.exception.InvalidVendorIDException;
import com.digitalgoldwallet.exception.UserNotFoundException;
import com.digitalgoldwallet.exception.VendorNotFoundException;
import com.digitalgoldwallet.model.Users;
import com.digitalgoldwallet.model.VendorBranches;
import com.digitalgoldwallet.service.vendorbranches.VendorbranchesService;

@RestController
@Validated
@RequestMapping(value="/api/v1/vendor_branches")
public class VendorbrancesController {
	
	
	
	@Autowired
	VendorbranchesService vendorServ;
	
	@GetMapping
	List<VendorBranches>GetAllVendorBranches(){
		List<VendorBranches>branches=vendorServ.GetAllVendorBranches();
		return branches;
	}
	@GetMapping(path="/{branch_id}")
	ResponseEntity< VendorBranches >findVendorbranchesByBranchID(@PathVariable("branch_id") int branch_id) throws InvalidBranchIDException, VendorBranchNotFoundException {
		VendorBranches VendorBranches=vendorServ.findVendorbranchesByBranchID(branch_id);
		
		if(branch_id <= 0) {
			throw new InvalidBranchIDException("vendorbranch id given is invalid");
		}
		if(VendorBranches == null) {
			throw new VendorBranchNotFoundException("vendorbranch with this id is not present");
		}
		return new ResponseEntity<VendorBranches>(VendorBranches,HttpStatus.OK);
	}
	

	@GetMapping(path="/by_vendor/{vendor_id}")
	ResponseEntity< VendorBranches >findVendorbranchesByVendorID(@PathVariable("vendor_id") int vendor_id) throws InvalidVendorIDException,  VendorBranchNotFoundException {
		VendorBranches vendors=vendorServ.findVendorbranchesByVendorID(vendor_id);
		if(vendor_id <= 0) {
			throw new InvalidVendorIDException("vendorbranch id given is invalid");
		}
		if(vendors == null) {
			throw new VendorBranchNotFoundException("vendorbranch with this id is not present");
		}
		return new ResponseEntity<VendorBranches>(vendors,HttpStatus.OK);
		
		
	}
	
	
	
	@PostMapping("/add")
	ResponseEntity<SuccessResponse> addVendorBranch(@RequestBody VendorBranches add) throws DuplicateVendorBranchException{
		if(add.getBranchid() <= 0) {
			throw new DuplicateVendorBranchException("Id given is already in use!");
		}
		vendorServ.addVendorBranch(add);
		SuccessResponse response = new SuccessResponse("Vendor Branch transfer was successfully", LocalDateTime.now());
		ResponseEntity<SuccessResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
		return responseEntity;
	}
	
	
	@PutMapping("/update/{branch_id}")
	ResponseEntity<VendorBranches> updateVendorBranches(@RequestBody VendorBranches branch_id) throws InvalidBranchIDException{
		if(branch_id.getBranchid() <= 0) {
			throw new InvalidBranchIDException("The id given is invalid!");
		}
		VendorBranches branches=vendorServ.updateVendorBranches(branch_id);
		SuccessResponse response = new SuccessResponse("Vendor Branch updated successfully", LocalDateTime.now());
		return new ResponseEntity<VendorBranches>(branches,HttpStatus.ACCEPTED);	
	}
	
	
	
	@PostMapping("/transfer/{source_branch_id}/{destination_branchId}") 
	public ResponseEntity<String> transfer(
            @PathVariable int sourceBranchId,
            @PathVariable int destinationBranchId,
            @RequestParam double quantity)throws InvalidBranchIDException {
		 Object destinationVendor = null;
		Object sourceVendor = null;
		if (sourceVendor != null && destinationVendor != null) {
			 return ResponseEntity.ok("Transfer successful");
	        } else {
	            return ResponseEntity.badRequest().body("Invalid source or destination branch");
	        }
	}
	
	
	
	
	
	@GetMapping("/by_city/{city}")
    public ResponseEntity<List<VendorBranches>> findVendorbranchesByCity(@PathVariable String city) throws VendorBranchNotFoundException {
        List<VendorBranches> vendorBranches = vendorServ.findVendorbranchesByCity(city);
        if(city.isEmpty()) {
			throw new VendorBranchNotFoundException("Users with the given city are not present!");
		}
		return new ResponseEntity<List<VendorBranches>>(vendorBranches, HttpStatus.OK);
	}

    @GetMapping("/by_state/{state}")
    public ResponseEntity<List<VendorBranches>> findVendorbranchesByState(@PathVariable String state) throws VendorBranchNotFoundException {
        List<VendorBranches> vendorBranches = vendorServ.findVendorbranchesByState(state);
        if(state.isEmpty()) {
			throw new VendorBranchNotFoundException("Users with the given city are not present!");
		}
		return new ResponseEntity<List<VendorBranches>>(vendorBranches, HttpStatus.OK);
    }

    @GetMapping("/by_country/{country}")
    public ResponseEntity<List<VendorBranches>> findVendorbranchesByCountry(@PathVariable String country) throws VendorBranchNotFoundException {
        List<VendorBranches> vendorBranches = vendorServ.findVendorbranchesByCountry(country);
        if(country.isEmpty()) {
			throw new VendorBranchNotFoundException("Users with the given city are not present!");
		}
		return new ResponseEntity<List<VendorBranches>>(vendorBranches, HttpStatus.OK);
    }
}
	
		


	

		 
	

    


		
		

