package com.digitalgoldwallet.exception;

public enum TransactionType {
	
	SUCCESS,
	FAILURE

}
