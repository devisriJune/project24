package com.digitalgoldwallet.exception;

public class DuplicateVendorBranchException extends Exception {
	
	public DuplicateVendorBranchException(String message) {
		super(message);
	}

}
