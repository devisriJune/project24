package com.digitalgoldwallet.exception;

public class InvalidBranchIDException extends Exception {
	
	public InvalidBranchIDException(String message) {
		super(message);
	}

}
