package com.digitalgoldwallet.exception;

public class InvalidUserIDException extends Exception{
	
	public InvalidUserIDException(String message) {
		super(message);
	}

}
