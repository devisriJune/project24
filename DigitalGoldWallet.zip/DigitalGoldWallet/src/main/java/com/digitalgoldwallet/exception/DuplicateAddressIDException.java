package com.digitalgoldwallet.exception;

public class DuplicateAddressIDException extends Exception {
	
	public DuplicateAddressIDException(String message) {
		super(message);
	}

}
