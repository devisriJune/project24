package com.digitalgoldwallet.exception;

public class InvalidVendorIDException extends Exception {
	
	public InvalidVendorIDException(String message) {
		super(message);
	}

}
