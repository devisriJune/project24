package com.digitalgoldwallet.exception;

public class VendorBranchNotFoundException extends Exception {
	
	public VendorBranchNotFoundException(String message) {
		super(message);
	}

}
