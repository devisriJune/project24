package com.digitalgoldwallet.model;

public enum PaymentStatus {
	
	Success,
	Failure

}
