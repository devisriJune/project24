package com.digitalgoldwallet.model;

public enum PaymentMethod {
	
	Cash,
	Credit,
	Debit,
	NetBanking

}
