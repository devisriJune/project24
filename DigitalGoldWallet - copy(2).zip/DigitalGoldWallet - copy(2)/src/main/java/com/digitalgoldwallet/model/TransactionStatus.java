package com.digitalgoldwallet.model;

public enum TransactionStatus {
	
	SUCCESS,
	FAILURE

}
