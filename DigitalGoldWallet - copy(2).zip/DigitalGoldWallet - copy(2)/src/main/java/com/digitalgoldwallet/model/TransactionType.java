package com.digitalgoldwallet.model;

public enum TransactionType {
	
	SUCCESS,
	FAILURE

}
