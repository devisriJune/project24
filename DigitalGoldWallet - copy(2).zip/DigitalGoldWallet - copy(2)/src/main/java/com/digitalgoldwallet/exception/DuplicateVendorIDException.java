package com.digitalgoldwallet.exception;

public class DuplicateVendorIDException extends Exception{
	
	public DuplicateVendorIDException(String message) {
		super(message);
	}

}
