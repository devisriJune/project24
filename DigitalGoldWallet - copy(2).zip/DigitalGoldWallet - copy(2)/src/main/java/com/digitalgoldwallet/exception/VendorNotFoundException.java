package com.digitalgoldwallet.exception;

public class VendorNotFoundException extends Exception{
	
	public VendorNotFoundException(String message) {
		super(message);
	}

}
