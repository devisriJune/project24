package com.digitalgoldwallet.exception;

public class AddressNotFoundException extends Exception{
	
	public AddressNotFoundException(String message) {
		super(message);
	}

}
