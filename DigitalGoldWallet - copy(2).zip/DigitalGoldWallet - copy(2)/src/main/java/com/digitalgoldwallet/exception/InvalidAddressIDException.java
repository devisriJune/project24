package com.digitalgoldwallet.exception;

public class InvalidAddressIDException extends Exception {
	
	public InvalidAddressIDException(String message) {
		super(message);
	}

}
