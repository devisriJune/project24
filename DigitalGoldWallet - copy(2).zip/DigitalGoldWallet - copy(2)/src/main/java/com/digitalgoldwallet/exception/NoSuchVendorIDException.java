package com.digitalgoldwallet.exception;

public class NoSuchVendorIDException extends Exception{

	public NoSuchVendorIDException(String message) {
		super(message);
	}
}
