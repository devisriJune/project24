package com.digitalgoldwallet.exception;

public class PaymentsNotPresentException extends Exception{
	
	public PaymentsNotPresentException(String message) {
		super(message);
	}

}
