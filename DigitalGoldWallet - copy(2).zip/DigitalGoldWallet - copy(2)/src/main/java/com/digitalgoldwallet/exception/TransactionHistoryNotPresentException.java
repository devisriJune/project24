package com.digitalgoldwallet.exception;

public class TransactionHistoryNotPresentException extends Exception{
	
	public TransactionHistoryNotPresentException(String message) {
		super(message);
	}

}
