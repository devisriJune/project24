package com.digitalgoldwallet.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.digitalgoldwallet.dao.vendors.VendorsRepository;
import com.digitalgoldwallet.exception.AddressNotFoundException;
import com.digitalgoldwallet.exception.DuplicateAddressIDException;
import com.digitalgoldwallet.exception.DuplicateVendorIDException;
import com.digitalgoldwallet.exception.InvalidAddressIDException;
import com.digitalgoldwallet.exception.InvalidVendorIDException;
import com.digitalgoldwallet.exception.NoSuchVendorIDException;
import com.digitalgoldwallet.exception.VendorNotFoundException;
import com.digitalgoldwallet.model.Addresses;
import com.digitalgoldwallet.model.Vendors;
import com.digitalgoldwallet.service.vendors.VendorsServiceImpl;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class VendorServiceImplTest {
	
	@Mock
	private VendorsRepository vendorRepository;	
	
	@InjectMocks
	private VendorsServiceImpl vendorService;
	
	@Test
	public void testGetAllVendors_Positive() {
		
		List<Vendors> vendorList = new ArrayList<>();
		vendorList.add(new Vendors(101, "Sona Jewelers", "Your trusted source for authentic gold jewelry", "Rohit Verma", "rohit.sona@example.com", "+91 9876541230", "https://www.sonajewelers.com", 2200.00, 6400.00, LocalDateTime.now()));
		
		when(vendorRepository.findAll()).thenReturn(vendorList);
		
		//when
		List<Vendors> result = vendorService.getAllVendors();
		
		//Then
		assertEquals(1, result.size());
		assertEquals("Sona Jewelers", result.get(0).getVendorName());
		
		//verify
		verify(vendorRepository).findAll();
		
		
	}
	
	@Test
    public void testGetVendorById_Positive() throws InvalidVendorIDException, NoSuchVendorIDException{
		
		int vendorId = 101;
		Vendors vendor = new Vendors(101, "Sona Jewelers", "Your trusted source for authentic gold jewelry", "Rohit Verma", "rohit.sona@example.com", "+91 9876541230", "https://www.sonajewelers.com", 2200.00, 6400.00, LocalDateTime.now());
		when(vendorRepository.findById(vendorId)).thenReturn(Optional.of(vendor));
		//when
		Vendors foundVendor = vendorService.findVendorById(vendorId);
		//Then
		assertEquals(vendor,foundVendor);
		verify(vendorRepository).findById(vendorId);
	}
	
	@Test
	public void testGetVendorById_Negative() throws InvalidVendorIDException, VendorNotFoundException {
		int vendorId = -1;
		Vendors vendor = new Vendors(vendorId,"Sona Jewelers", "Your trusted source for authentic gold jewelry", "Rohit Verma", "rohit.sona@example.com", "+91 9876541230", "https://www.sonajewelers.com", 2200.00, 6400.00, LocalDateTime.now());
		when(vendorRepository.findById(-1)).thenReturn(Optional.empty());
		//Then
		assertThrows(InvalidVendorIDException.class, () -> {
			vendorService.findVendorById(vendorId);
		});
		
		verify(vendorRepository).findById(vendorId);
		
	}
	
	@Test
	public void testGetVendorByName_Positive() throws VendorNotFoundException {
		String vendorName = "Sona Jewelers";
		Vendors vendor = new Vendors(101,"Sona Jewelers", "Your trusted source for authentic gold jewelry", "Rohit Verma", "rohit.sona@example.com", "+91 9876541230", "https://www.sonajewelers.com", 2200.00, 6400.00, LocalDateTime.now());
		when(vendorRepository.findByVendorName(vendorName)).thenReturn(Optional.of(vendor));
		//when
		Vendors foundVendorName = vendorService.findVendorByVendorName(vendorName);
		//Then
		assertEquals(vendor,foundVendorName);
		verify(vendorRepository).findByVendorName(vendorName);
	}
	
	@Test
	public void testGetVendorByName_Negative() throws VendorNotFoundException {
		String vendorName = "Sathvika";
		Vendors vendor = new Vendors(101,vendorName, "Your trusted source for authentic gold jewelry", "Rohit Verma", "rohit.sona@example.com", "+91 9876541230", "https://www.sonajewelers.com", 2200.00, 6400.00, LocalDateTime.now());
		when(vendorRepository.findByVendorName("Sathvika")).thenReturn(Optional.empty());
		//Then
		assertThrows(VendorNotFoundException.class, () -> {
			vendorService.findVendorByVendorName(vendorName);
		});
		verify(vendorRepository).findByVendorName(vendorName);
	}
	
	@Test
	public void testAddVendor_Positive() throws DuplicateVendorIDException{
		//Given
		Vendors addNewVendor = new Vendors(15,"Golden Heritage", "Preserving India’s rich heritage in gold craftsmanship", "Ananya Kapoor", "ananya.goldenheritage@example.com", "+91 9871239876", "https://www.goldenheritageindia.in", 2800.00, 6400.00, LocalDateTime.now());
		
		when(vendorRepository.findById(15)).thenReturn(Optional.empty());
		when(vendorRepository.saveAndFlush(addNewVendor)).thenReturn(addNewVendor);
		
		//when
		int vendor = vendorService.addVendor(addNewVendor);
		//Then
		assertEquals(15,vendor);
		verify(vendorRepository).findById(15);
		verify(vendorRepository).saveAndFlush(addNewVendor);
		
	}
	
}


/*
 @Test
	public void testAddAddress_Positive() throws DuplicateAddressIDException  {
		// Given
		Addresses add = new Addresses(101,"123 Main Street", "Mumbai", "Maharashtra", "400001", "India");
		when(addressRepository.findById(101)).thenReturn(Optional.empty());
		when(addressRepository.saveAndFlush(add)).thenReturn(add);
 
		// When
		Addresses address = addressService.addAddress(add);
 
		// Then
		assertEquals(101, address.getAddressId());
		verify(addressRepository).findById(101);
		verify(addressRepository).saveAndFlush(add);
	}
	@Test
	public void testAddAddress_Negative() throws DuplicateAddressIDException{
		// Given
		Addresses existingAddress = new Addresses(101,"123 Main Street", "Mumbai", "Maharashtra", "400001", "India");
		when(addressRepository.findById(101)).thenReturn(Optional.of(existingAddress));
 
		// Then
		assertThrows(DuplicateAddressIDException.class, () -> {
		// When
		addressService.addAddress(existingAddress);
		});
 
		// Verify that saveAndFlush method is not called
		verify(addressRepository, never()).saveAndFlush(existingAddress);
	}
 */

