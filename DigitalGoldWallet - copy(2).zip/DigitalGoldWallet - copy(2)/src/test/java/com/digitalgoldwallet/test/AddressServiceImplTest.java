package com.digitalgoldwallet.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.digitalgoldwallet.dao.addresses.AddressRepository;
import com.digitalgoldwallet.exception.AddressNotFoundException;
import com.digitalgoldwallet.exception.DuplicateAddressIDException;
import com.digitalgoldwallet.exception.InvalidAddressIDException;
import com.digitalgoldwallet.model.Addresses;
import com.digitalgoldwallet.service.addresses.AddressServiceImpl;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class AddressServiceImplTest {
	
	@Mock
	private AddressRepository addressRepository;
	
	@InjectMocks
	private AddressServiceImpl addressService;
	
	@Test
	public void testGetAllAddresses() {
		
		//Given
		List<Addresses> address = new ArrayList<>();
		
		address.add(new Addresses(101,"123 Main Street", "Mumbai", "Maharashtra", "400001", "India"));
		
		when(addressRepository.findAll()).thenReturn(address);

		// When
		List<Addresses> result = addressService.GetAllAddresses();

		// Then
		assertEquals(1, result.size());
		assertEquals("Maharashtra", result.get(0).getState());

		verify(addressRepository).findAll();
				
	}
	
	@Test
	public void testAddAddress_Positive() throws DuplicateAddressIDException  {
		// Given
		Addresses add = new Addresses(101,"123 Main Street", "Mumbai", "Maharashtra", "400001", "India");
		when(addressRepository.findById(101)).thenReturn(Optional.empty());
		when(addressRepository.saveAndFlush(add)).thenReturn(add);
 
		// When
		Addresses address = addressService.addAddress(add);
 
		// Then
		assertEquals(101, address.getAddressId());
		verify(addressRepository).findById(101);
		verify(addressRepository).saveAndFlush(add);
	}
	@Test
	public void testAddAddress_Negative() throws DuplicateAddressIDException{
		// Given
		Addresses existingAddress = new Addresses(101,"123 Main Street", "Mumbai", "Maharashtra", "400001", "India");
		when(addressRepository.findById(101)).thenReturn(Optional.of(existingAddress));
 
		// Then
		assertThrows(DuplicateAddressIDException.class, () -> {
		// When
		addressService.addAddress(existingAddress);
		});
 
		// Verify that saveAndFlush method is not called
		verify(addressRepository, never()).saveAndFlush(existingAddress);
	}
	@Test
	public void testGetAddressById_Positive() throws InvalidAddressIDException, AddressNotFoundException {
		
		int addressId = 101;
		Addresses address = new Addresses(addressId, "Gulf Street", "Pune", "Maharashtra", "400231", "India");
		when(addressRepository.findById(addressId)).thenReturn(Optional.of(address));
		//when
		Addresses foundAddress = addressService.GetAddressById(addressId);
		//Then
		assertEquals(address,foundAddress);
		verify(addressRepository).findById(addressId);
			
	}
	
	@Test
	public void testGetAddressById_Negative() throws InvalidAddressIDException, AddressNotFoundException {
		int addressId = -1;
		Addresses address = new Addresses(addressId, "Gulf Street", "Pune", "Maharashtra", "400231", "India");
		when(addressRepository.findById(-1)).thenReturn(Optional.empty());
		//Then
		assertThrows(InvalidAddressIDException.class, () -> {
			addressService.GetAddressById(addressId);
		});
		
		verify(addressRepository).findById(addressId);
		
	}
	@Test
	public void testUpdateAddress_Positive() throws AddressNotFoundException{
		
		Addresses address = new Addresses(101,"123 Main Street", "Mumbai", "Maharashtra", "400001", "India");
		
		when(addressRepository.findById(101)).thenReturn(Optional.of(address));
		
		Addresses updatedaddress = new Addresses();
		updatedaddress.setAddressId(101);
		updatedaddress.setCity("Bangalore");
		updatedaddress.setCountry("India");
		updatedaddress.setPostalCode("400002");
		updatedaddress.setState("Karnataka");
		updatedaddress.setStreet("123 Main Street");

		addressService.updateAddress(updatedaddress);
		
		verify(addressRepository, never()).saveAndFlush(updatedaddress);
		
	}
	
	@Test
	public void testUpdateAddress_Negative() throws AddressNotFoundException{
       // Given
       Addresses addressToUpdate = new Addresses(-1,"2929 Galaxy Road", "Allahabad", "Uttar Pradesh", "211001", "India");
       // Stubbing the behavior of the mock AddressRepository to return empty optional
       when(addressRepository.findById(-1)).thenReturn(Optional.empty());
       // When and Then
       assertThrows(AddressNotFoundException.class, () -> {
           addressService.updateAddress(addressToUpdate);
       });
	}
	
	
	
	
	
	

}
